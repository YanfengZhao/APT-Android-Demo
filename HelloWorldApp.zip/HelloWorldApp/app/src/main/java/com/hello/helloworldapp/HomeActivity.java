package com.hello.helloworldapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.apache.http.Header;


public class HomeActivity extends ActionBarActivity {

    public static String REQUEST_URL = "http://connexusraga.appspot.com/serveurl";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, new PlaceholderFragment())
                    .commit();
        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        private String TAG  = "PlaceholderFragment";
        private AsyncHttpClient httpClient = new AsyncHttpClient();

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_home, container, false);
            final Button requestButton = (Button) rootView.findViewById(R.id.request_button);
            final TextView responseText = (TextView) rootView.findViewById(R.id.response_text);
            requestButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    httpClient.get(REQUEST_URL, new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                            responseText.setText(new String(response));
                        }

                        @Override
                        public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                            Log.e(TAG,"There was a problem in retrieving the url : " + e.toString());
                        }
                    });
                }
            });
            return rootView;
        }
    }
}
